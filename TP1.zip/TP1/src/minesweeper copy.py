from cmu_graphics import *
import random
from types import SimpleNamespace

# Implementation Ideas:
   # intro graphics
   # app.safety toggle

# Bugs to Fix:   
   # first click protection (generatefield around first click?)
   # graphics:
   #    control instructions
   #    mouse hover -> word movement

   
'''
   Controls:
   - Left-click an empty square to reveal it.
   - Right-click (or Ctrl+click) an empty square to flag it.
   - Midde-click (or left+right click) a number to reveal
     its adjacent squares.
   - Press space bar while hovering over a square to flag
     it or reveal its adjacent squares. 
   - Press r to restart.
     
'''


#helpers#

def generateField(r, c, numOfMines, firstClick):
    board = [[False for _ in range(c)] for _ in range(r)]
    mines = 0
    while mines < numOfMines:
        randR = random.randint(0, r-1)
        randC = random.randint(0, c-1)
        if (randR,randC) in firstClick:
            continue
        elif not board[randR][randC]:
            board[randR][randC] = True
            mines += 1
    return board

def surroundingFirstClick(firstCell):
    firstClick = set()
    row,col = firstCell
    for dRow in [-1, 0 ,1]:
        for dCol in [-1, 0, 1]:
            firstClick.add((row+dRow, col+dCol))
    return firstClick

def getCell(app, x, y):
    col = x // app.cellWidth
    row = y //app.cellHeight
    return int(row), int(col)

def checkMine(app, r, c):
    test = app.board[r][c]
    if type(test) == bool and test:
        app.gameOver = True
        app.timing = False
        return
    checkNeighbors(app, r, c, set())
    
def checkNeighbors(app, r, c, seen):
    if (r >= len(app.board) or c >= len(app.board[0]) or 
            r < 0 or c < 0):
        return
    elif (r, c) in seen:
        return
    app.board[r][c] = countNeighbors(app, r, c)
    seen.add((r, c))
    if app.board[r][c] == None:
        checkNeighbors(app, r, c+1, seen)
        checkNeighbors(app, r+1, c, seen)
        checkNeighbors(app, r-1, c, seen)
        checkNeighbors(app, r, c-1, seen)
        checkNeighbors(app, r-1, c-1, seen)
        checkNeighbors(app, r+1, c+1, seen)
        checkNeighbors(app, r-1, c+1, seen)
        checkNeighbors(app, r+1, c-1, seen)
    else: 
        return

def clearNeighbors(app, row, col):
    for drow in [-1, 0, 1]:
        for dcol in [-1, 0, 1]:
            testRow = row+drow
            testCol = col+dcol
            if testRow not in range(0, len(app.board)) or testCol not in range(0, len(app.board[0])):
                continue
            if testRow == row and testCol == col:
                continue
            test = app.board[testRow][testCol]
            valuesToPass = {'mine', 'flag'}
            if test in valuesToPass:
                continue
            elif isinstance(test, bool) and test:
                app.gameOver = True
                app.timing = False
            elif test == None:
                checkNeighbors(app, testRow, testCol, set())
            else:
                app.board[testRow][testCol] = countNeighbors(app, testRow, testCol)
    
def countNeighbors(app, row, col):
    count = 0
    for drow in [-1, 0, 1]:
        for dcol in [-1, 0, 1]:
            testRow = row+drow
            testCol = col+dcol
            if testRow not in range(0, len(app.board)) or testCol not in range(0, len(app.board[0])):
                continue
            if testRow == row and testCol == col:
                continue
            test = app.board[testRow][testCol]
            if type(test) == int:
                continue
            if test or test == 'mine':
                count += 1
    if count != 0:
        return count

def noNeighboringMines(app, row, col):
    for drow in [-1, 0, 1]:
        for dcol in [-1, 0, 1]:
            testRow = row+drow
            testCol = col+dcol
            if testRow not in range(0, len(app.board)) or testCol not in range(0, len(app.board[0])):
                continue
            test = app.board[testRow][testCol]
            if type(test) == bool and test:
                return False
    return True

def checkWin(app):
    count = 0
    for row in app.board:
        for v in row:
            if type(v) == bool or v == 'mine':
                count += 1
    return count == app.numOfMines
    
def appIntro(app):
    intro = SimpleNamespace()
    intro.title = False
    intro.instructions = False
    intro.quip = False
    intro.start = False
    intro.play = True
    return intro

def endIntro(app):
    app.intro.play = False
    app.step = 0
    app.intro.start = False
    
def restart(app):
    app.numOfMines = 9
    app.rows = 9
    app.cols = 10
    app.cellWidth = app.cellHeight = 30
    app.board = [[False for _ in range(app.cols)] for _ in range(app.rows)]

    app.space = False
    app.newBoard = True
    app.gameOver = False
    app.winner = False
    
    app.step = 0
    app.grow = False
    app.wordSize = app.width/18
    app.titleSize = app.width/12
    app.dSize = 0.5
    app.max = app.wordSize + 8
    app.min = app.wordSize - 8
    
##############################################################
##############################################################

def onAppStart(app):
    app.cx = app.cy = 0
    restart(app)
    app.timing = True
    app.intro = appIntro(app)

#########################drawing##############################
##############################################################

def redrawAll(app):
    if app.intro.play:
        drawIntro(app)
        return
    
    drawBoard(app)
            
    if app.gameOver: drawGameOver(app)
    elif app.winner: pass

def drawBoard(app):
    for row in range(app.rows):
        for col in range(app.cols):
            cellLeft = col * app.cellWidth
            cellTop = row * app.cellHeight
            cell = app.board[row][col]
            if type(cell) == int or cell == None:
                cellColor = 'darkGray'
            elif app.gameOver and cell:
                cellColor = 'darkRed'
            else:
                cellColor = 'gray'
                
            drawRect(cellLeft, cellTop, app.cellWidth, app.cellHeight, 
            fill = cellColor, border = 'black', borderWidth = 0.5)
            
            if cell == 'flag' or cell == 'mine':
                drawCircle(cellLeft + app.cellWidth/2, cellTop + app.cellHeight/2, app.cellWidth/4,
                    fill = 'red')
            elif type(cell) != bool:
                label = cell if cell != None else ''
                drawLabel(label, cellLeft + app.cellWidth/2, cellTop + app.cellHeight/2,
                font = 'orbitron', size = 16)

def drawIntro(app):
    drawRect(0, 0, app.width, app.height, fill = 'green')
    drawLabel('Minesweeper', app.width/2, app.height/8, 
         font = 'orbitron', size = app.titleSize, visible = app.intro.title)
    drawLabel('Find all the mines without', app.width/2, app.height/2, fill = 'red',
         font = 'orbitron', size = app.width/17, visible = app.intro.quip)
    drawLabel('blowing up!!!', app.width/2, app.height/2 + app.height/15, fill = 'red',
         font = 'orbitron', size = app.width/17, visible = app.intro.quip)
    drawLabel('Click anywhere to start', app.width/2, 3*app.height/4,
         font = 'orbitron', size = app.width/20, visible = app.intro.start)

def drawInstructions(app):
    drawLabel('Hold spacebar to flag or', app.width/2, 1.15*app.height/4,
         font = 'orbitron', size = app.width/20, visible = app.intro.instructions)
    drawLabel('clear surrounding mines.', app.width/2, 1.35*app.height/4,
         font = 'orbitron', size = app.width/20, visible = app.intro.instructions)
    drawLabel('Click the timer to pause.', app.width/2, 1.7*app.height/4,
         font = 'orbitron', size = app.width/20, visible = app.intro.instructions)

def drawWinner(app):
    time = app.step // 30
    drawRect(app.width/4, app.height/2 - app.height/16, app.width/2, app.height/7, fill = 'maroon')
    drawRect(app.width/12, 8*app.height/20, 5*app.width/6, app.height/12, fill = 'maroon')
    drawLabel('Congrats!!!', app.width/2, app.height/2 + app.height/30, size = app.wordSize, font = 'orbitron', fill = 'red')
    drawLabel(f'You got it in {time} seconds', app.width/2, app.height/2 - app.height/17, size = app.width/16, 
         font = 'orbitron')
    
def drawGameOver(app):
    drawLabel('GAME OVER :(', app.width/2, app.height/2, size = app.wordSize, 
        font = 'orbitron', fill = 'red', bold = True)
    
##########################################################################
    
def onMouseMove(app, mouseX, mouseY):
    app.cx = mouseX
    app.cy = mouseY
    
    if app.intro.start and app.cy < app.height/4:
        app.grow = True
    else:
        app.grow = False

def onMousePress(app, mouseX, mouseY):
    if app.intro.play:
        endIntro(app)
        return
    
    #restart after loss
    elif app.gameOver:
        restart(app)
        return
    
    #restart after winning
    elif app.winner:
        restart(app)
        return
    
    #play minesweeper
    else:
        if app.newBoard: 
            app.newBoard = False
            firstCell = getCell(app, app.cx, app.cy)
            firstClick = surroundingFirstClick(firstCell)
            app.board = generateField(app.rows, app.cols, app.numOfMines, firstClick)

        row, col = getCell(app, mouseX, mouseY)
        cell = app.board[row][col]
        
        if app.space:
            return
        elif cell == 'mine' or cell == 'flag' or type(cell) == int:
            return
        else:
            checkMine(app, row, col)

    if checkWin(app):
        app.winner = True
        app.min += 4
        app.dSize = 0.3
        
def onKeyPress(app, key):
    if app.intro.start:
        endIntro(app)
        return
    if key == 'space':
        app.space = True
        row, col = getCell(app, app.cx, app.cy)
        cell = app.board[row][col]
        if type(cell) == int: 
            if not noNeighboringMines(app, row, col):
                return
            clearNeighbors(app, row, col)
        elif cell == 'mine':
            app.board[row][col] = True
        elif cell == 'flag':
            app.board[row][col] = False
        elif cell == False:
            app.board[row][col] = 'flag'
        elif cell == True:
            app.board[row][col] = 'mine'
    if key == 'r':
        restart(app)
    
def onKeyRelease(app, key):
    if key == 'space':
        app.space = False

def onStep(app):
    app.step += 1
    if app.intro.play:
        app.intro.title = True
        if app.step == 20: app.intro.instructions = True
        if app.step == 20: app.intro.quip = True
        if app.step == 50:
            app.intro.start = True
            app.timing = False
          
    if (app.gameOver or (app.intro.play and app.intro.start) or app.winner):
        app.titleSize += app.dSize
        app.wordSize += app.dSize
        if app.wordSize <= app.min or app.wordSize >= app.max:
            app.dSize *= -1

def prettyPrint(L):
    print('\n\n')
    for row in L:
        print(row)
        


runApp(width = 900, height = 480)