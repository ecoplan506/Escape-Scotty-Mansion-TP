from cmu_graphics import *


def intro_onAppStart(app):
    app.cx = 0
    app.cy = 0
    app.alert = []
    app.power = True

def intro_onMouseMove(app, mouseX, mouseY):
    app.cx = mouseX
    app.cy = mouseY

def intro_onScreenActivate(app):
    pass

def intro_redrawAll(app):
    drawRect(0, 0, app.width, app.width)
    drawLabel("Escape Scotty Mansion!!!", app.cx, app.cy, fill = 'red', size = app.width//20, font = 'montserrat')


runAppWithScreens(initialScreen='intro')